package practical;

public class Palindrome{
public static boolean isPalindrome(int number) {
int reversed = 0;
int original = number;

while (original > 0) {
int digit = original % 10;
reversed = reversed * 10 + digit;
original /= 10;
}

return reversed == number;
}

public static void main(String[] args) {
System.out.println(isPalindrome(1001));
System.out.println(isPalindrome(1111));
System.out.println(isPalindrome(1221));
System.out.println(isPalindrome(1331));
System.out.println(isPalindrome(1441));
System.out.println(isPalindrome(1100));
System.out.println(isPalindrome(1210));
System.out.println(isPalindrome(1110));
}
}