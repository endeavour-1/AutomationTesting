package practical;

import org.junit.Test;
import static org.junit.Assert.*;

public class TestSuite {

@Test
public void testIsPalindrome() {
assertTrue(Palindrome.isPalindrome(1001));
assertTrue(Palindrome.isPalindrome(1111));
assertTrue(Palindrome.isPalindrome(1221));
assertTrue(Palindrome.isPalindrome(1331));
assertTrue(Palindrome.isPalindrome(1441));
assertFalse(Palindrome.isPalindrome(1100));
assertFalse(Palindrome.isPalindrome(1210));
assertFalse(Palindrome.isPalindrome(1110));
}
}